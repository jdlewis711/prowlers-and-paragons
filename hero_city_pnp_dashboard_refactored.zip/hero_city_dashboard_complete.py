import tkinter as tk
from tkinter import ttk, messagebox, simpledialog

from rules_window import RulesWindow
from dice_roller import DiceRoller
import json
import random
from datetime import datetime
from pathlib import Path

# ============================================================
# HERO CITY — PROWLERS & PARAGONS GM DASHBOARD
# ============================================================
#
# Standard-library only: tkinter + json + pathlib.
#
# The program is intentionally divided into sections so a GM can
# find and modify one part without needing to understand the whole app.
# DATA = campaign information; GENERATORS = optional random content;
# GUI = screens and buttons; SAVE = JSON/text persistence.
#
# Files created beside this script:
#   hero_city_data.json   -> campaign database
#   session log.txt       -> running session notes
#
# Run:
#   python hero_city_dashboard.py
# ============================================================

DATA_FILE = Path("hero_city_data.json")
SESSION_LOG = Path("session log.txt")


# ============================================================
# DEFAULT DATA
# ============================================================

DEFAULT_DATA = {
    "heroes": [
        {
            "name": "Sentinel",
            "aliases": ["The Sentinel", "Blue Guardian"],
            "powers": ["super strength", "flight", "enhanced durability"],
            "feats": ["Stopped a runaway armored truck downtown"],
            "teams": ["Independent"],
            "weaknesses": [],
            "civilian_identity": "Unknown",
            "reputation": "Generally admired",
            "sightings": [],
        },
        {
            "name": "Volt",
            "aliases": ["Voltage"],
            "powers": ["electricity manipulation", "electrical sensing"],
            "feats": ["Prevented a citywide blackout"],
            "teams": ["Independent"],
            "weaknesses": [],
            "civilian_identity": "Unknown",
            "reputation": "Generally positive",
            "sightings": [],
        },
        {
            "name": "Nightshade",
            "aliases": ["Shade"],
            "powers": ["shadow manipulation", "stealth", "enhanced agility"],
            "feats": ["Stopped a jewelry store robbery"],
            "teams": ["Unknown"],
            "weaknesses": [],
            "civilian_identity": "Unknown",
            "reputation": "Mysterious",
            "sightings": [],
        },
    ],
    "villains": [],
    "places": [
        {
            "name": "Downtown",
            "type": "District",
            "description": "The commercial heart of Hero City.",
            "tags": ["business", "skyscrapers", "crime"],
            "associated_people": [],
            "incidents": [],
        },
        {
            "name": "Old Harbor",
            "type": "Waterfront",
            "description": "Industrial docks, warehouses, bars, and shipping yards.",
            "tags": ["industrial", "waterfront", "smuggling"],
            "associated_people": [],
            "incidents": [],
        },
        {
            "name": "Hero City University",
            "type": "University",
            "description": "A major urban university campus.",
            "tags": ["students", "science", "research"],
            "associated_people": [],
            "incidents": [],
        },
        {
            "name": "Founders Park",
            "type": "Park",
            "description": "A massive public park in central Hero City.",
            "tags": ["park", "families", "events"],
            "associated_people": [],
            "incidents": [],
        },
        {
            "name": "Mercer Avenue",
            "type": "Street",
            "description": "A busy commercial avenue running through several neighborhoods.",
            "tags": ["shopping", "traffic", "restaurants"],
            "associated_people": [],
            "incidents": [],
        },
    ],
    "organizations": [
        {
            "name": "Hero City Police Department",
            "type": "Government",
            "description": "Municipal police department.",
            "members": [],
            "notes": "",
        },
        {
            "name": "Hero City University",
            "type": "University",
            "description": "Major research university.",
            "members": [],
            "notes": "",
        },
    ],
    "npcs": [
        {
            "name": "Maya Torres",
            "alias": "Pulse",
            "role": "Journalist / Influencer",
            "description": "Independent journalist with a reputation for being first to major superhero stories.",
            "relationships": [],
            "notes": "",
        },
    ],
    "social_users": [
        {
            "username": "Pulse",
            "display_name": "Maya Torres",
            "type": "journalist",
            "bio": "Independent journalist. Finger on the pulse of Hero City.",
            "weight": 8,
        },
        {
            "username": "CityWatchHC",
            "display_name": "Hero City Watch",
            "type": "news",
            "bio": "Local news, traffic, emergencies, and civic updates.",
            "weight": 4,
        },
        {
            "username": "HCFoodie",
            "display_name": "Sam Chen",
            "type": "local",
            "bio": "Food, neighborhoods, and trying not to get caught in superhuman fights.",
            "weight": 5,
        },
        {
            "username": "NightOwl92",
            "display_name": "Derek Miller",
            "type": "civilian",
            "bio": "Usually awake when the weird stuff happens.",
            "weight": 4,
        },
        {
            "username": "HeroFan4Life",
            "display_name": "Ashley Reed",
            "type": "fan",
            "bio": "I have opinions about every hero. Yes, including yours.",
            "weight": 5,
        },
        {
            "username": "HCTransit",
            "display_name": "Hero City Transit",
            "type": "official",
            "bio": "Service alerts for Hero City's public transportation system.",
            "weight": 3,
        },
        {
            "username": "OldTownLocal",
            "display_name": "Frank Delgado",
            "type": "local",
            "bio": "Third generation Hero City resident.",
            "weight": 3,
        },
        {
            "username": "ConspiracyCorner",
            "display_name": "TruthSeekerHC",
            "type": "conspiracy",
            "bio": "Asking the questions the heroes don't want you asking.",
            "weight": 2,
        },
        {
            "username": "HCScanner",
            "display_name": "ScannerRat",
            "type": "scanner",
            "bio": "Not affiliated with emergency services. Probably.",
            "weight": 4,
        },
    ],
    "posts": [],
    "incidents": [],
}


LOCATION_TEMPLATES = [
    ("The Glass District", "District", "A wealthy neighborhood dominated by modern architecture.", ["wealth", "corporate", "nightlife"]),
    ("Blackstone Station", "Transit", "A major subway and commuter rail station.", ["transit", "crowds", "crime"]),
    ("Rook Street", "Street", "A narrow street known for pawn shops, bars, and unusual nightlife.", ["nightlife", "crime", "underground"]),
    ("Starlight Plaza", "Plaza", "A popular downtown gathering place surrounded by restaurants and shops.", ["tourism", "shopping", "events"]),
    ("Westbridge", "Neighborhood", "A dense residential neighborhood west of downtown.", ["residential", "families", "working-class"]),
    ("The Narrows", "Neighborhood", "A crowded waterfront district with a reputation for organized crime.", ["crime", "waterfront", "poverty"]),
    ("Mercy General Hospital", "Hospital", "One of Hero City's largest hospitals.", ["medical", "emergency", "heroes"]),
    ("Atlas Tower", "Building", "A 70-story corporate tower overlooking downtown.", ["corporate", "wealth", "technology"]),
    ("Hawthorne Bridge", "Bridge", "A major bridge connecting downtown with Westbridge.", ["traffic", "river", "infrastructure"]),
    ("Redline Subway", "Transit", "The city's oldest subway line.", ["transit", "underground", "crime"]),
]

HERO_TEMPLATES = [
    ("The Warden", ["Warden"], ["energy barriers", "enhanced strength"]),
    ("Mirage", ["The Mirage"], ["illusion generation", "disguise"]),
    ("Comet", ["Comet"], ["flight", "super speed", "energy projection"]),
    ("Ironclad", ["Ironclad"], ["super durability", "super strength"]),
    ("Specter", ["The Specter"], ["intangibility", "invisibility"]),
]

VILLAIN_TEMPLATES = [
    ("Blackout", ["The Blackout"], ["power absorption", "electrical disruption"]),
    ("Gravitas", ["Gravitas"], ["gravity manipulation"]),
    ("The Broker", ["Broker"], ["superhuman persuasion", "information networks"]),
    ("Razorwing", ["Razorwing"], ["flight", "energy blades"]),
    ("Morrow", ["Doctor Morrow"], ["biotechnology", "mutagenic science"]),
]

FEATS = [
    "Stopped a robbery before police arrived",
    "Rescued civilians from a collapsing building",
    "Prevented a major traffic accident",
    "Fought an unidentified superhuman in public",
    "Stopped an armed gang near a residential neighborhood",
    "Evacuated civilians during a superhuman incident",
    "Prevented a train derailment",
    "Destroyed a dangerous piece of supervillain technology",
    "Helped firefighters contain a major fire",
    "Interrupted a suspected weapons deal",
    "Protected civilians during a hostage situation",
    "Was seen fighting someone on a rooftop",
]

POST_TEMPLATES = {
    "sighting": [
        "Anyone else see {hero} near {place} tonight?",
        "Just saw {hero} heading toward {place}. Something is definitely happening.",
        "Possible {hero} sighting at {place}. Can anyone confirm?",
        "Okay, pretty sure that was {hero} flying over {place}.",
    ],
    "news": [
        "BREAKING: Reports of a superhuman incident near {place}.",
        "Emergency crews responding to an incident at {place}.",
        "Multiple witnesses reporting unusual activity around {place}.",
        "Police have closed several streets around {place}.",
    ],
    "fan": [
        "{hero} continues to prove why they're one of the best heroes in Hero City.",
        "I don't care what anyone says. {hero} is AWESOME.",
        "If {hero} is actually at {place}, somebody better get video.",
        "Hero City doesn't deserve {hero}.",
    ],
    "complaint": [
        "Can someone explain why {place} is closed AGAIN?",
        "Love living in Hero City. Nothing like hearing an explosion outside your window.",
        "Apparently superhuman property damage doesn't count as a parking violation.",
        "Would really appreciate it if superheroes stopped destroying {place}. Thanks.",
    ],
    "rumor": [
        "Hearing rumors that {hero} was involved in what happened at {place}.",
        "Friend of a friend says there were TWO heroes at {place}.",
        "Apparently {hero} wasn't alone at {place}.",
        "Something weird is going on at {place}. That's all I'm saying.",
    ],
    "pulse": [
        "I've spoken with three witnesses who independently described {hero} at {place}. Still trying to confirm what happened.",
        "NEW: Multiple sources tell me {hero} was seen at {place} shortly before the incident.",
        "I'm getting reports of unusual activity at {place}. If you're nearby, send me what you're seeing.",
        "I've been tracking reports of {hero} for the last few weeks. Tonight's sighting at {place} is the clearest one yet.",
        "People are asking whether {hero} is connected to the incident at {place}. At this point, that's unconfirmed.",
    ],
    "conspiracy": [
        "Funny how {hero} always shows up right after something happens at {place}.",
        "You're telling me nobody knows who {hero} really is?",
        "Something doesn't add up about {place}.",
        "Ask yourself who benefits from what happened at {place}.",
    ],
    "local": [
        "Anyone know if the businesses around {place} are still open?",
        "Had dinner near {place} and suddenly half the street was blocked off.",
        "Hero City really needs to figure out its superhuman insurance situation.",
        "Honestly, {place} was already weird BEFORE the superheroes showed up.",
    ],
    "scanner": [
        "Scanner traffic suggests units heading toward {place}.",
        "Hearing reports of a possible powered individual at {place}.",
        "Multiple emergency units moving toward {place}.",
        "Something big happening around {place}.",
    ],
}


# ============================================================
# DATA FUNCTIONS
# ============================================================

def fresh_data():
    return json.loads(json.dumps(DEFAULT_DATA))


def migrate_legacy_fields(data):
    """Upgrade older campaign files without destroying existing information."""
    for key in ("heroes", "villains"):
        for record in data.get(key, []):
            if "teams" not in record:
                record["teams"] = record.pop("affiliations", ["Unknown"])
            record.setdefault("teams", ["Unknown"])
            record.setdefault("sightings", [])

    data.setdefault("incidents", [])
    data.setdefault("npcs", [])
    data.setdefault("organizations", [])

    # Preserve older character files while making secret identities NPC-based.
    for key in ("heroes", "villains"):
        for record in data.get(key, []):
            record.setdefault("aliases", [])
            record.setdefault("civilian_identity", "Unknown")

            identity = record.get("civilian_identity", "")
            aliases = record.get("aliases", [])
            if identity and identity != "Unknown" and (
                not aliases or aliases == ["Unknown"]
            ):
                record["aliases"] = [identity]

    return data


def load_data():
    if not DATA_FILE.exists():
        return fresh_data()
    try:
        with DATA_FILE.open("r", encoding="utf-8") as f:
            data = json.load(f)
        # Add any new keys from later versions.
        defaults = fresh_data()
        for key, value in defaults.items():
            data.setdefault(key, value)
        return migrate_legacy_fields(data)
    except Exception:
        messagebox.showwarning(
            "Data Error",
            "Could not read hero_city_data.json. Starting with a fresh database."
        )
        return fresh_data()


def save_data(data):
    with DATA_FILE.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def weighted_user(data):
    users = data["social_users"]
    pool = []
    for user in users:
        pool.extend([user] * int(user.get("weight", 1)))
    return random.choice(pool)


def choose_person(data, include_villains=True):
    choices = []
    choices.extend([("hero", x) for x in data["heroes"]])
    if include_villains:
        choices.extend([("villain", x) for x in data["villains"]])
    return random.choice(choices) if choices else (None, None)


def choose_place(data):
    return random.choice(data["places"]) if data["places"] else None


def find_record(records, name):
    name = name.lower().strip()
    for record in records:
        if record.get("name", "").lower() == name:
            return record
    return None


# ============================================================
# SOCIAL FEED ENGINE
# ============================================================

def generate_post(data):
    user = weighted_user(data)
    _, person = choose_person(data)
    place = choose_place(data)

    if not person or not place:
        return None

    person_name = person["name"]
    place_name = place["name"]

    if user["username"] == "Pulse":
        category = "pulse"
    elif user["type"] == "fan":
        category = "fan"
    elif user["type"] == "conspiracy":
        category = "conspiracy"
    elif user["type"] == "scanner":
        category = "scanner"
    elif user["type"] == "news":
        category = "news"
    elif user["type"] == "local":
        category = random.choice(["local", "complaint"])
    else:
        category = random.choice(["sighting", "rumor", "local", "complaint"])

    text = random.choice(POST_TEMPLATES[category]).format(
        hero=person_name,
        place=place_name,
    )

    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    post = {
        "id": len(data["posts"]) + 1,
        "timestamp": now,
        "username": user["username"],
        "display_name": user["display_name"],
        "type": user["type"],
        "text": text,
        "person": person_name,
        "place": place_name,
        "category": category,
        "verified": user["username"] == "Pulse",
    }

    data["posts"].append(post)

    # Track sightings/incidents.
    if category in ("sighting", "pulse", "rumor", "scanner"):
        person.setdefault("sightings", []).append({
            "place": place_name,
            "timestamp": now,
            "source": user["username"],
            "confirmed": category == "pulse",
        })

        place.setdefault("incidents", []).append({
            "timestamp": now,
            "person": person_name,
            "source": user["username"],
            "description": text,
        })

    # Pulse occasionally turns a sighting into a recorded feat.
    if category == "pulse" and random.random() < 0.22:
        feat = random.choice(FEATS)
        if feat not in person.setdefault("feats", []):
            person["feats"].append(feat)
            post["database_update"] = feat

    return post


def record_major_incident(data, title, location_name, heroes, villains, scenario, outcome):
    """
    Save a major incident supplied by the GM.

    Unlike the original random incident generator, this function records
    what actually happened during the game: the GM chooses the participants,
    location, scenario, and consequences.
    """
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    incident = {
        "id": len(data.get("incidents", [])) + 1,
        "timestamp": now,
        "title": title,
        "location": location_name,
        "heroes": heroes,
        "villains": villains,
        "scenario": scenario,
        "outcome": outcome,
    }

    data.setdefault("incidents", []).insert(0, incident)

    # Keep the location history synchronized with the campaign-wide history.
    place = find_record(data.get("places", []), location_name)
    if place:
        place.setdefault("incidents", []).insert(0, incident)

    # A confirmed game event becomes a confirmed sighting for each participant.
    for person_name in heroes:
        person = find_record(data.get("heroes", []), person_name)
        if person is not None:
            person.setdefault("sightings", []).append({
                "place": location_name,
                "timestamp": now,
                "source": "Major Incident",
                "confirmed": True,
            })

    for person_name in villains:
        person = find_record(data.get("villains", []), person_name)
        if person is not None:
            person.setdefault("sightings", []).append({
                "place": location_name,
                "timestamp": now,
                "source": "Major Incident",
                "confirmed": True,
            })

    # Pulse publishes a public-facing summary so the event also appears in
    # the fictional social-media feed.
    data["posts"].append({
        "id": len(data["posts"]) + 1,
        "timestamp": now,
        "username": "Pulse",
        "display_name": "Maya Torres",
        "type": "journalist",
        "text": (
            f"BREAKING: {title} reported at {location_name}. "
            f"Heroes involved: {', '.join(heroes) or 'none confirmed'}. "
            f"Villains involved: {', '.join(villains) or 'none confirmed'}."
        ),
        "person": ", ".join(heroes + villains),
        "place": location_name,
        "category": "major incident",
        "verified": True,
    })

    return incident


def introduce_hero(data):
    existing = {x["name"] for x in data["heroes"]}
    available = [x for x in HERO_TEMPLATES if x[0] not in existing]
    if not available:
        return None

    name, aliases, powers = random.choice(available)
    hero = {
        "name": name,
        "aliases": aliases,
        "powers": powers,
        "feats": [],
        "teams": ["Unknown"],
        "weaknesses": [],
        "civilian_identity": "Unknown",
        "reputation": "Unknown",
        "sightings": [],
    }
    data["heroes"].append(hero)
    return hero


def introduce_villain(data):
    existing = {x["name"] for x in data["villains"]}
    available = [x for x in VILLAIN_TEMPLATES if x[0] not in existing]
    if not available:
        return None

    name, aliases, powers = random.choice(available)
    villain = {
        "name": name,
        "aliases": aliases,
        "powers": powers,
        "feats": [],
        "teams": ["Unknown"],
        "weaknesses": [],
        "civilian_identity": "Unknown",
        "reputation": "Dangerous",
        "sightings": [],
        "crimes": [],
    }
    data["villains"].append(villain)
    return villain


def discover_place(data):
    existing = {x["name"] for x in data["places"]}
    available = [x for x in LOCATION_TEMPLATES if x[0] not in existing]
    if not available:
        return None

    name, kind, description, tags = random.choice(available)
    place = {
        "name": name,
        "type": kind,
        "description": description,
        "tags": tags,
        "associated_people": [],
        "incidents": [],
    }
    data["places"].append(place)
    return place


# ============================================================
# MAIN APPLICATION
# ============================================================
# The class below is the GUI controller. Each build_* method creates one
# screen; each save_* method persists the GM's changes.
# ============================================================

class HeroCityApp:
    BG = "#11151c"
    PANEL = "#1a2029"
    PANEL2 = "#202733"
    TEXT = "#e8edf2"
    MUTED = "#9aa6b2"
    ACCENT = "#4aa3ff"
    ACCENT2 = "#f0b429"
    DANGER = "#e35d6a"

    def __init__(self, root):
        self.root = root
        self.root.title("Hero City — Prowlers & Paragons GM Dashboard")
        self.root.geometry("1280x820")
        self.root.minsize(1000, 650)

        self.data = load_data()
        self.current_page = "Social Feed"
        self.current_record = None

        self.configure_style()
        self.build_ui()
        self.show_page("Social Feed")

        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def open_game_tools(self):
        """Open the rules and dice tools from the Hero City title."""
        win = tk.Toplevel(self.root)
        win.title("Hero City — Game Tools")
        win.geometry("420x260")
        win.resizable(False, False)
        win.configure(bg=self.BG)

        tk.Label(
            win, text="HERO CITY", bg=self.BG, fg=self.TEXT,
            font=("Segoe UI", 18, "bold")
        ).pack(pady=(28, 4))
        tk.Label(
            win, text="Prowlers & Paragons Game Tools", bg=self.BG, fg=self.MUTED,
            font=("Segoe UI", 10)
        ).pack(pady=(0, 20))

        ttk.Button(
            win, text="RULES", width=28,
            command=lambda: RulesWindow(self.root, Path(__file__).with_name("prowlersampparagonsultimateedition.pdf"))
        ).pack(pady=6)
        ttk.Button(
            win, text="ROLL DICE", width=28,
            command=lambda: DiceRoller(self.root)
        ).pack(pady=6)

    def configure_style(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure(
            "TButton",
            background=self.PANEL2,
            foreground=self.TEXT,
            padding=(12, 8),
            borderwidth=0,
        )
        style.map(
            "TButton",
            background=[("active", self.ACCENT)],
            foreground=[("active", "#ffffff")],
        )
        style.configure(
            "Treeview",
            background=self.PANEL,
            foreground=self.TEXT,
            fieldbackground=self.PANEL,
            rowheight=30,
            borderwidth=0,
        )
        style.configure(
            "Treeview.Heading",
            background=self.PANEL2,
            foreground=self.TEXT,
            padding=8,
        )
        style.map(
            "Treeview",
            background=[("selected", self.ACCENT)],
            foreground=[("selected", "#ffffff")],
        )

    def build_ui(self):
        self.root.configure(bg=self.BG)

        # ---------------- TOP BANNER ----------------
        banner = tk.Frame(self.root, bg="#0b0f14", height=70)
        banner.pack(fill="x", side="top")
        banner.pack_propagate(False)

        title = tk.Button(
            banner,
            text="HERO CITY",
            command=self.open_game_tools,
            bg="#0b0f14",
            fg="#ffffff",
            activebackground="#0b0f14",
            activeforeground="#ffffff",
            relief="flat",
            bd=0,
            font=("Segoe UI", 20, "bold"),
            cursor="hand2",
        )
        title.pack(side="left", padx=(22, 4))

        subtitle = tk.Label(
            banner,
            text="PROWLERS & PARAGONS • GM DASHBOARD",
            bg="#0b0f14",
            fg=self.MUTED,
            font=("Segoe UI", 9),
        )
        subtitle.pack(side="left", padx=8)

        nav = tk.Frame(banner, bg="#0b0f14")
        nav.pack(side="right", padx=15)

        buttons = [
            ("SOCIAL FEED", "Social Feed"),
            ("HEROES", "Heroes"),
            ("VILLAINS", "Villains"),
            ("PLACES", "Places"),
            ("NPCS", "NPCs"),
            ("ORGANIZATIONS", "Organizations"),
            ("SESSION NOTES", "Session Notes"),
        ]

        for label, page in buttons:
            b = tk.Button(
                nav,
                text=label,
                command=lambda p=page: self.show_page(p),
                bg="#18202a",
                fg=self.TEXT,
                activebackground=self.ACCENT,
                activeforeground="#ffffff",
                relief="flat",
                bd=0,
                padx=14,
                pady=11,
                font=("Segoe UI", 9, "bold"),
                cursor="hand2",
            )
            b.pack(side="left", padx=3)

        # ---------------- MAIN AREA ----------------
        self.content = tk.Frame(self.root, bg=self.BG)
        self.content.pack(fill="both", expand=True)

        # ---------------- STATUS BAR ----------------
        self.status = tk.Label(
            self.root,
            text="Ready",
            bg="#0b0f14",
            fg=self.MUTED,
            anchor="w",
            padx=15,
            pady=5,
            font=("Segoe UI", 9),
        )
        self.status.pack(fill="x", side="bottom")

    def clear_content(self):
        for child in self.content.winfo_children():
            child.destroy()

    def show_page(self, page):
        self.current_page = page
        self.clear_content()

        if page == "Social Feed":
            self.build_social_page()
        elif page == "Heroes":
            self.build_people_page("heroes", "HERO LEXICON")
        elif page == "Villains":
            self.build_people_page("villains", "VILLAIN DATABASE")
        elif page == "Places":
            self.build_places_page()
        elif page == "NPCs":
            self.build_reference_page("npcs", "NPC DATABASE", "NPC")
        elif page == "Organizations":
            self.build_reference_page("organizations", "ORGANIZATION DATABASE", "Organization")
        elif page == "Session Notes":
            self.build_session_page()

        self.status.config(text=f"{page} • {datetime.now().strftime('%Y-%m-%d %H:%M')}")

    # ========================================================
    # SOCIAL FEED
    # ========================================================

    def build_social_page(self):
        left = tk.Frame(self.content, bg=self.BG)
        left.pack(side="left", fill="both", expand=True, padx=(18, 8), pady=18)

        right = tk.Frame(self.content, bg=self.PANEL, width=290)
        right.pack(side="right", fill="y", padx=(8, 18), pady=18)
        right.pack_propagate(False)

        header = tk.Frame(left, bg=self.BG)
        header.pack(fill="x", pady=(0, 10))

        tk.Label(
            header,
            text="LIVE HERO CITY FEED",
            bg=self.BG,
            fg=self.TEXT,
            font=("Segoe UI", 16, "bold"),
        ).pack(side="left")

        ttk.Button(
            header,
            text="Generate Post",
            command=self.add_generated_post,
        ).pack(side="right", padx=4)

        ttk.Button(
            header,
            text="Major Incident",
            command=self.add_major_incident,
        ).pack(side="right", padx=4)

        ttk.Button(
            header,
            text="Refresh",
            command=lambda: self.show_page("Social Feed"),
        ).pack(side="right", padx=4)

        self.feed_text = tk.Text(
            left,
            bg=self.PANEL,
            fg=self.TEXT,
            insertbackground="#ffffff",
            selectbackground=self.ACCENT,
            relief="flat",
            wrap="word",
            padx=18,
            pady=15,
            font=("Segoe UI", 10),
        )
        self.feed_text.pack(fill="both", expand=True)
        self.feed_text.configure(state="disabled")

        self.render_feed()

        self.make_panel_title(right, "CITY INTELLIGENCE")

        ttk.Button(
            right,
            text="Discover New Hero",
            command=self.add_hero,
        ).pack(fill="x", padx=18, pady=(10, 5))

        ttk.Button(
            right,
            text="Discover New Villain",
            command=self.add_villain,
        ).pack(fill="x", padx=18, pady=5)

        ttk.Button(
            right,
            text="Discover New Place",
            command=self.add_place,
        ).pack(fill="x", padx=18, pady=5)

        ttk.Button(
            right,
            text="Search Everything",
            command=self.search_everything,
        ).pack(fill="x", padx=18, pady=5)

        self.make_panel_title(right, "CAMPAIGN COUNTS")

        stats = (
            f"Heroes: {len(self.data['heroes'])}\n"
            f"Villains: {len(self.data['villains'])}\n"
            f"Places: {len(self.data['places'])}\n"
            f"NPCs: {len(self.data['npcs'])}\n"
            f"Organizations: {len(self.data['organizations'])}\n"
            f"Social posts: {len(self.data['posts'])}"
        )

        tk.Label(
            right,
            text=stats,
            bg=self.PANEL,
            fg=self.MUTED,
            justify="left",
            font=("Segoe UI", 10),
        ).pack(anchor="w", padx=18, pady=8)

    def render_feed(self):
        self.feed_text.configure(state="normal")
        self.feed_text.delete("1.0", "end")

        for post in reversed(self.data["posts"][-100:]):
            verified = " ✓" if post.get("verified") else ""

            self.feed_text.insert(
                "end",
                f"@{post['username']}{verified}",
                ("username",),
            )
            self.feed_text.insert(
                "end",
                f"  {post['display_name']}  •  {post['timestamp']}\n",
                ("meta",),
            )
            self.feed_text.insert(
                "end",
                post["text"] + "\n",
            )

            if post.get("database_update"):
                self.feed_text.insert(
                    "end",
                    f"  [DATABASE UPDATE] {post['database_update']}\n",
                    ("update",),
                )

            self.feed_text.insert(
                "end",
                f"  #{post.get('category', '')}  •  {post.get('place', '')}\n\n",
                ("tag",),
            )

        self.feed_text.tag_configure(
            "username",
            foreground=self.ACCENT,
            font=("Segoe UI", 10, "bold"),
        )
        self.feed_text.tag_configure(
            "meta",
            foreground=self.MUTED,
        )
        self.feed_text.tag_configure(
            "update",
            foreground=self.ACCENT2,
        )
        self.feed_text.tag_configure(
            "tag",
            foreground="#6f7d8c",
            font=("Segoe UI", 9),
        )

        self.feed_text.configure(state="disabled")

    def add_generated_post(self):
        post = generate_post(self.data)
        if post:
            save_data(self.data)
            self.show_page("Social Feed")

    def add_major_incident(self):
        """Open the GM-controlled major incident builder."""
        self.open_incident_builder()

    def open_incident_builder(self):
        """Open a scrollable form for recording a major campaign incident."""
        win = tk.Toplevel(self.root)
        win.title("Major Incident Builder")
        win.geometry("900x760")
        win.minsize(700, 500)
        win.configure(bg=self.BG)
        win.transient(self.root)
        win.grab_set()

        # A Canvas + vertical scrollbar makes the entire form scrollable.
        # This prevents the Save button from being pushed below the window
        # when the GM's scenario/outcome text is long.
        canvas = tk.Canvas(win, bg=self.BG, highlightthickness=0)
        scrollbar = ttk.Scrollbar(win, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)

        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        form = tk.Frame(canvas, bg=self.BG)
        window_id = canvas.create_window((0, 0), window=form, anchor="nw")

        def update_scroll_region(event=None):
            canvas.configure(scrollregion=canvas.bbox("all"))
            canvas.itemconfigure(window_id, width=canvas.winfo_width())

        form.bind("<Configure>", update_scroll_region)
        canvas.bind("<Configure>", update_scroll_region)

        # Mouse-wheel scrolling.
        def wheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

        canvas.bind_all("<MouseWheel>", wheel)

        def close_window():
            canvas.unbind_all("<MouseWheel>")
            win.destroy()

        win.protocol("WM_DELETE_WINDOW", close_window)

        tk.Label(
            form, text="MAJOR INCIDENT BUILDER", bg=self.BG, fg=self.TEXT,
            font=("Segoe UI", 18, "bold")
        ).pack(anchor="w", padx=20, pady=(20, 0))

        tk.Label(
            form,
            text="Record what happened at the table. You choose the participants and scenario.",
            bg=self.BG, fg=self.MUTED
        ).pack(anchor="w", padx=20, pady=(3, 12))

        def labeled_entry(label):
            tk.Label(form, text=label, bg=self.BG, fg=self.MUTED).pack(
                anchor="w", padx=20, pady=(7, 2)
            )
            entry = tk.Entry(
                form, bg=self.PANEL, fg=self.TEXT,
                insertbackground="#fff", relief="flat"
            )
            entry.pack(fill="x", padx=20, ipady=7)
            return entry

        title_entry = labeled_entry("Incident Title")

        tk.Label(form, text="Location", bg=self.BG, fg=self.MUTED).pack(
            anchor="w", padx=20, pady=(7, 2)
        )
        location_var = tk.StringVar()
        location_box = ttk.Combobox(
            form, textvariable=location_var, state="readonly",
            values=[p["name"] for p in self.data["places"]]
        )
        location_box.pack(fill="x", padx=20, ipady=4)
        if self.data["places"]:
            location_box.current(0)

        participants = tk.Frame(form, bg=self.BG)
        participants.pack(fill="x", padx=20, pady=12)

        hero_box_frame = tk.Frame(participants, bg=self.PANEL)
        hero_box_frame.pack(side="left", fill="both", expand=True, padx=(0, 6))
        villain_box_frame = tk.Frame(participants, bg=self.PANEL)
        villain_box_frame.pack(side="left", fill="both", expand=True, padx=(6, 0))

        tk.Label(
            hero_box_frame, text="HEROES INVOLVED", bg=self.PANEL, fg=self.TEXT,
            font=("Segoe UI", 10, "bold")
        ).pack(anchor="w", padx=10, pady=8)

        hero_list = tk.Listbox(
            hero_box_frame, selectmode="multiple", bg=self.PANEL,
            fg=self.TEXT, selectbackground=self.ACCENT, relief="flat",
            height=8
        )
        hero_list.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        for hero in self.data["heroes"]:
            hero_list.insert("end", hero["name"])

        tk.Label(
            villain_box_frame, text="VILLAINS INVOLVED", bg=self.PANEL, fg=self.TEXT,
            font=("Segoe UI", 10, "bold")
        ).pack(anchor="w", padx=10, pady=8)

        villain_list = tk.Listbox(
            villain_box_frame, selectmode="multiple", bg=self.PANEL,
            fg=self.TEXT, selectbackground=self.ACCENT, relief="flat",
            height=8
        )
        villain_list.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        for villain in self.data["villains"]:
            villain_list.insert("end", villain["name"])

        def labeled_text(label, height):
            tk.Label(
                form, text=label, bg=self.BG, fg=self.MUTED
            ).pack(anchor="w", padx=20, pady=(7, 2))

            text = tk.Text(
                form, height=height, bg=self.PANEL, fg=self.TEXT,
                insertbackground="#fff", relief="flat", wrap="word"
            )
            text.pack(fill="x", padx=20)
            return text

        scenario = labeled_text("Scenario / What Happened", 9)
        outcome = labeled_text("Outcome / Consequences", 7)

        button_bar = tk.Frame(form, bg=self.BG)
        button_bar.pack(fill="x", padx=20, pady=15)

        def save_incident():
            """Validate and write the incident; keep the window open on error."""
            title = title_entry.get().strip()
            location = location_var.get().strip()

            if not title or not location:
                messagebox.showerror(
                    "Incomplete Incident",
                    "Enter an incident title and choose a location.",
                    parent=win
                )
                return

            heroes = [hero_list.get(i) for i in hero_list.curselection()]
            villains = [villain_list.get(i) for i in villain_list.curselection()]
            scenario_text = scenario.get("1.0", "end-1c").strip()
            outcome_text = outcome.get("1.0", "end-1c").strip()

            if not scenario_text:
                messagebox.showerror(
                    "Incomplete Incident",
                    "Describe what happened.",
                    parent=win
                )
                return

            try:
                # Make the campaign change only after validation succeeds.
                incident = record_major_incident(
                    self.data, title, location, heroes, villains,
                    scenario_text, outcome_text
                )
                save_data(self.data)

            except Exception as exc:
                messagebox.showerror(
                    "Could Not Save Incident",
                    "Hero City could not save this incident.\n\n"
                    f"Error: {exc}\n\n"
                    "Your writing is still in the form. Correct the problem "
                    "and press Save Major Incident again.",
                    parent=win,
                )
                return

            messagebox.showinfo(
                "Incident Saved",
                f"'{title}' was saved to the Hero City campaign database.",
                parent=win,
            )
            close_window()
            self.show_page("Social Feed")
            self.status.config(text=f"Saved major incident: {title}")

        ttk.Button(
            button_bar, text="Save Major Incident", command=save_incident
        ).pack(side="right", padx=(8, 0))

        ttk.Button(
            button_bar, text="Cancel", command=close_window
        ).pack(side="right")

        # Start at the top of the form.
        canvas.yview_moveto(0)


    def build_people_page(self, key, title):
        """Build the Hero Lexicon or Villain Database screen."""
        container = tk.Frame(self.content, bg=self.BG)
        container.pack(fill="both", expand=True, padx=18, pady=18)

        top = tk.Frame(container, bg=self.BG)
        top.pack(fill="x", pady=(0, 10))

        tk.Label(
            top, text=title, bg=self.BG, fg=self.TEXT,
            font=("Segoe UI", 16, "bold")
        ).pack(side="left")

        # The GM can add a character manually, generate one, or delete the
        # selected character from the active roster. Historical incidents
        # and social posts are deliberately preserved when deleting.
        ttk.Button(
            top, text="Delete Selected",
            command=lambda: self.delete_person(key, tree)
        ).pack(side="right", padx=4)

        ttk.Button(
            top, text=f"Add {'Hero' if key == 'heroes' else 'Villain'}",
            command=self.manual_add_person
        ).pack(side="right", padx=4)

        ttk.Button(
            top, text="Generate Random",
            command=(self.add_hero if key == "heroes" else self.add_villain)
        ).pack(side="right", padx=4)

        search_var = tk.StringVar()
        tk.Entry(
            top, textvariable=search_var, bg=self.PANEL, fg=self.TEXT,
            insertbackground="#ffffff", relief="flat", font=("Segoe UI", 10)
        ).pack(side="right", padx=8, ipadx=10, ipady=7)
        tk.Label(top, text="Search:", bg=self.BG, fg=self.MUTED).pack(side="right")

        tree_frame = tk.Frame(container, bg=self.PANEL)
        tree_frame.pack(fill="both", expand=True)

        tree = ttk.Treeview(
            tree_frame,
            columns=("name", "aliases", "powers", "teams", "reputation"),
            show="headings",
            selectmode="browse",
        )

        headings = {
            "name": "Name",
            "aliases": "Aliases",
            "powers": "Powers",
            "teams": "Teams",
            "reputation": "Reputation",
        }
        widths = {
            "name": 160, "aliases": 180, "powers": 320,
            "teams": 180, "reputation": 200,
        }

        for col in headings:
            tree.heading(col, text=headings[col])
            tree.column(col, width=widths[col], anchor="w")
        tree.pack(side="left", fill="both", expand=True)

        scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
        scrollbar.pack(side="right", fill="y")
        tree.configure(yscrollcommand=scrollbar.set)

        def populate(*_):
            """Rebuild the table so search and saved edits appear immediately."""
            tree.delete(*tree.get_children())
            query = search_var.get().lower()

            for record in self.data[key]:
                if query and query not in json.dumps(record).lower():
                    continue

                tree.insert(
                    "", "end", iid=record.get("name", ""),
                    values=(
                        record.get("name", ""),
                        ", ".join(record.get("aliases", [])),
                        ", ".join(record.get("powers", [])),
                        ", ".join(record.get("teams", [])),
                        record.get("reputation", ""),
                    ),
                )

        search_var.trace_add("write", populate)
        populate()
        tree.bind("<Double-1>", lambda event: self.open_person_record(key, tree))

        tk.Label(
            container,
            text="Double-click a name to edit its dossier. Click Save Dossier to keep changes.",
            bg=self.BG, fg=self.MUTED
        ).pack(anchor="w", pady=(8, 0))

    def delete_person(self, key, tree):
        """Delete the selected hero or villain from the active roster."""
        selected = tree.selection()
        if not selected:
            messagebox.showinfo("Delete", "Select a hero or villain first.")
            return

        name = tree.item(selected[0], "values")[0]
        kind = "hero" if key == "heroes" else "villain"

        if not messagebox.askyesno(
            "Confirm Deletion",
            f"Remove {name} from the active {kind} roster?\n\n"
            "Past incidents and social posts will remain in the campaign history."
        ):
            return

        self.data[key][:] = [r for r in self.data[key] if r.get("name") != name]
        save_data(self.data)
        self.show_page("Heroes" if key == "heroes" else "Villains")

    def open_person_record(self, key, tree):
        selected = tree.selection()
        if not selected:
            return

        values = tree.item(selected[0], "values")
        if not values:
            return

        record = find_record(self.data[key], values[0])
        if not record:
            return

        self.person_editor(key, record)

    def person_editor(self, key, record):
        """Open a scrollable, editable hero/villain dossier."""
        win = tk.Toplevel(self.root)
        win.title(f"{record['name']} — Dossier")
        win.geometry("760x720")
        win.minsize(650, 500)
        win.configure(bg=self.BG)
        win.transient(self.root)
        win.grab_set()

        canvas = tk.Canvas(win, bg=self.BG, highlightthickness=0)
        scrollbar = ttk.Scrollbar(win, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        form = tk.Frame(canvas, bg=self.BG)
        window_id = canvas.create_window((0, 0), window=form, anchor="nw")

        def update_scroll_region(event=None):
            canvas.configure(scrollregion=canvas.bbox("all"))
            canvas.itemconfigure(window_id, width=canvas.winfo_width())

        form.bind("<Configure>", update_scroll_region)
        canvas.bind("<Configure>", update_scroll_region)

        def wheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

        canvas.bind_all("<MouseWheel>", wheel)

        def close_window():
            canvas.unbind_all("<MouseWheel>")
            win.destroy()

        win.protocol("WM_DELETE_WINDOW", close_window)

        tk.Label(
            form, text="CHARACTER DOSSIER", bg=self.BG, fg=self.TEXT,
            font=("Segoe UI", 18, "bold")
        ).pack(anchor="w", padx=20, pady=(20, 8))

        fields = {}
        entries = [
            ("Hero Name/Villain Name", "name"),
            ("Secret Identity", "aliases"),
            ("Powers (comma separated)", "powers"),
            ("Teams (comma separated)", "teams"),
            ("Weaknesses (comma separated)", "weaknesses"),
            ("Public Reputation", "reputation"),
        ]

        # Hero/Villain name and other ordinary text fields.
        for label, field_name in entries:
            tk.Label(
                form, text=label, bg=self.BG, fg=self.MUTED, anchor="w"
            ).pack(fill="x", padx=20, pady=(7, 2))

            if field_name == "aliases":
                # Secret identity is represented by an NPC record.
                npc_records = self.data.setdefault("npcs", [])
                npc_names = [
                    str(n.get("name", "")).strip()
                    for n in npc_records
                    if str(n.get("name", "")).strip()
                ]

                current_identity = ""
                aliases = record.get("aliases", [])
                if isinstance(aliases, list):
                    current_identity = aliases[0].strip() if aliases else ""
                else:
                    current_identity = str(aliases).strip()

                matched = next(
                    (n for n in npc_records
                     if str(n.get("name", "")).strip().lower() == current_identity.lower()),
                    None
                )

                npc_var = tk.StringVar(
                    value=str(matched.get("name", "")).strip() if matched else ""
                )
                npc_combo = ttk.Combobox(
                    form,
                    textvariable=npc_var,
                    values=npc_names,
                    state="readonly",
                )
                npc_combo.pack(fill="x", padx=20, ipady=3)
                fields[field_name] = npc_combo

                tk.Label(
                    form,
                    text="Select the NPC who is this character's secret identity.",
                    bg=self.BG,
                    fg=self.MUTED,
                    anchor="w",
                ).pack(fill="x", padx=20, pady=(2, 6))
            else:
                entry = tk.Entry(
                    form, bg=self.PANEL, fg=self.TEXT,
                    insertbackground="#ffffff", relief="flat"
                )
                value = record.get(field_name, "")
                if isinstance(value, list):
                    value = ", ".join(value)
                entry.insert(0, value)
                entry.pack(fill="x", padx=20, ipady=7)
                fields[field_name] = entry

        def add_text_field(label, field_name, height):
            tk.Label(
                form, text=label, bg=self.BG, fg=self.MUTED, anchor="w"
            ).pack(fill="x", padx=20, pady=(10, 2))

            text = tk.Text(
                form, height=height, bg=self.PANEL, fg=self.TEXT,
                insertbackground="#ffffff", relief="flat", wrap="word"
            )
            text.pack(fill="x", padx=20)
            fields[field_name] = text
            return text

        feats = add_text_field("Known Feats (one per line)", "feats", 5)
        feats.insert("1.0", "\n".join(record.get("feats", [])))

        crimes = None
        if key == "villains":
            crimes = add_text_field(
                "Known Crimes / Major Offenses (one per line)",
                "crimes", 5
            )
            crimes.insert("1.0", "\n".join(record.get("crimes", [])))

        sightings = add_text_field(
            "Sightings (one per line; free-form campaign notes)", "sightings", 6
        )

        sighting_lines = []
        for item in record.get("sightings", []):
            if isinstance(item, dict):
                sighting_lines.append(
                    f"{item.get('timestamp', '')} — "
                    f"{item.get('place', '')} — "
                    f"{item.get('source', '')}"
                )
            else:
                sighting_lines.append(str(item))
        sightings.insert("1.0", "\n".join(sighting_lines))

        button_bar = tk.Frame(form, bg=self.BG)
        button_bar.pack(fill="x", padx=20, pady=15)

        def save():
            """Write every field to the live record and JSON database."""
            new_name = fields["name"].get().strip()

            if not new_name:
                messagebox.showerror(
                    "Save Error", "Name cannot be blank.", parent=win
                )
                return

            records = self.data[key]
            duplicate = any(
                r is not record and r.get("name") == new_name
                for r in records
            )

            if duplicate:
                messagebox.showerror(
                    "Save Error",
                    f"{new_name} already exists.",
                    parent=win
                )
                return

            try:
                record["name"] = new_name

                # Secret identity is always stored as the linked NPC's name.
                selected_npc = fields["aliases"].get().strip()

                if key == "heroes" and not selected_npc:
                    create_npc = messagebox.askyesno(
                        "Secret Identity NPC",
                        "This hero does not have an NPC selected for their secret identity.\\n\\n"
                        "Would you like to create an NPC for the hero's secret identity now?",
                        parent=win,
                    )

                    if create_npc:
                        self.create_npc_for_secret_identity(
                            suggested_name="",
                            parent=win,
                        )
                        npc_records = self.data.setdefault("npcs", [])
                        npc_names = [
                            str(n.get("name", "")).strip()
                            for n in npc_records
                            if str(n.get("name", "")).strip()
                        ]
                        fields["aliases"]["values"] = npc_names
                        if npc_names:
                            fields["aliases"].set(npc_names[-1])
                            selected_npc = npc_names[-1]

                    if not selected_npc:
                        messagebox.showwarning(
                            "Secret Identity Required",
                            "Every hero must be linked to an NPC representing their secret identity.",
                            parent=win,
                        )
                        return

                record["aliases"] = [selected_npc] if selected_npc else []

                for field_name in ["powers", "teams", "weaknesses"]:
                    record[field_name] = [
                        x.strip()
                        for x in fields[field_name].get().split(",")
                        if x.strip()
                    ]

                record["reputation"] = fields["reputation"].get().strip()
                record["feats"] = [
                    x.strip()
                    for x in feats.get("1.0", "end-1c").splitlines()
                    if x.strip()
                ]

                if crimes is not None:
                    record["crimes"] = [
                        x.strip()
                        for x in crimes.get("1.0", "end-1c").splitlines()
                        if x.strip()
                    ]

                record["sightings"] = [
                    x.strip()
                    for x in sightings.get("1.0", "end-1c").splitlines()
                    if x.strip()
                ]

                save_data(self.data)

            except Exception as exc:
                messagebox.showerror(
                    "Could Not Save Dossier",
                    "The dossier could not be written to the campaign database.\n\n"
                    f"Error: {exc}\n\n"
                    "Your changes are still open in this window.",
                    parent=win,
                )
                return

            messagebox.showinfo(
                "Dossier Saved",
                f"{record['name']} has been saved.",
                parent=win
            )
            close_window()
            self.show_page("Heroes" if key == "heroes" else "Villains")
            self.status.config(text=f"Saved {record['name']} dossier")

        ttk.Button(
            button_bar, text="Save Dossier", command=save
        ).pack(side="right", padx=4)

        ttk.Button(
            button_bar, text="Cancel", command=close_window
        ).pack(side="right", padx=4)

        ttk.Button(
            button_bar,
            text="Delete Character",
            command=lambda: self.delete_from_editor(key, record, win)
        ).pack(side="left")

        canvas.yview_moveto(0)


    def delete_from_editor(self, key, record, editor_window):
        """Delete a character while its dossier window is open."""
        kind = "hero" if key == "heroes" else "villain"
        if not messagebox.askyesno(
            "Confirm Deletion",
            f"Delete {record.get('name', 'this character')} from the active {kind} roster?",
            parent=editor_window
        ):
            return

        self.data[key][:] = [r for r in self.data[key] if r is not record]
        save_data(self.data)
        editor_window.destroy()
        self.show_page("Heroes" if key == "heroes" else "Villains")

    def manual_add_person(self):
        """Create a hero/villain. Heroes must be linked to an NPC identity."""
        key = "heroes" if self.current_page == "Heroes" else "villains"
        kind = "Hero" if key == "heroes" else "Villain"

        if key == "villains":
            name = simpledialog.askstring(
                f"New {kind}",
                f"{kind} name:",
                parent=self.root,
            )
            if not name:
                return

            powers = simpledialog.askstring(
                f"New {kind}",
                "Powers (comma separated):",
                parent=self.root,
            ) or ""

            record = {
                "name": name,
                "aliases": [],
                "powers": [x.strip() for x in powers.split(",") if x.strip()],
                "feats": [],
                "teams": ["Unknown"],
                "weaknesses": [],
                "civilian_identity": "Unknown",
                "reputation": "Unknown",
                "sightings": [],
                "crimes": [],
            }
            self.data[key].append(record)
            save_data(self.data)
            self.show_page("Villains")
            return

        # ---------------- HERO CREATION ----------------
        win = tk.Toplevel(self.root)
        win.title("New Hero")
        win.geometry("560x430")
        win.minsize(500, 380)
        win.configure(bg=self.BG)
        win.transient(self.root)
        win.grab_set()

        tk.Label(
            win,
            text="CREATE NEW HERO",
            bg=self.BG,
            fg=self.TEXT,
            font=("Segoe UI", 18, "bold"),
        ).pack(anchor="w", padx=24, pady=(22, 8))

        tk.Label(
            win,
            text="Hero Name",
            bg=self.BG,
            fg=self.MUTED,
        ).pack(anchor="w", padx=24, pady=(8, 2))

        name_entry = tk.Entry(
            win,
            bg=self.PANEL,
            fg=self.TEXT,
            insertbackground="#ffffff",
            relief="flat",
        )
        name_entry.pack(fill="x", padx=24, ipady=8)

        tk.Label(
            win,
            text="Powers (comma separated)",
            bg=self.BG,
            fg=self.MUTED,
        ).pack(anchor="w", padx=24, pady=(10, 2))

        powers_entry = tk.Entry(
            win,
            bg=self.PANEL,
            fg=self.TEXT,
            insertbackground="#ffffff",
            relief="flat",
        )
        powers_entry.pack(fill="x", padx=24, ipady=8)

        tk.Label(
            win,
            text="Secret Identity NPC",
            bg=self.BG,
            fg=self.MUTED,
        ).pack(anchor="w", padx=24, pady=(10, 2))

        npc_records = self.data.setdefault("npcs", [])
        npc_names = [
            str(n.get("name", "")).strip()
            for n in npc_records
            if str(n.get("name", "")).strip()
        ]

        npc_var = tk.StringVar()
        npc_combo = ttk.Combobox(
            win,
            textvariable=npc_var,
            values=npc_names,
            state="readonly",
        )
        npc_combo.pack(fill="x", padx=24, ipady=3)

        tk.Label(
            win,
            text="Select an existing NPC. If the secret identity is not in the NPC database, leave this blank and the GM will be prompted to create one.",
            bg=self.BG,
            fg=self.MUTED,
            wraplength=500,
            justify="left",
        ).pack(anchor="w", padx=24, pady=(4, 8))

        def create_new_identity():
            suggested = simpledialog.askstring(
                "New Secret Identity NPC",
                "NPC name / secret identity:",
                parent=win,
            )
            if not suggested:
                return

            self.create_npc_for_secret_identity(
                suggested_name=suggested.strip(),
                parent=win,
            )

            npc_records[:] = self.data.setdefault("npcs", [])
            npc_names[:] = [
                str(n.get("name", "")).strip()
                for n in npc_records
                if str(n.get("name", "")).strip()
            ]
            npc_combo["values"] = npc_names

            if suggested.strip() in npc_names:
                npc_var.set(suggested.strip())

        ttk.Button(
            win,
            text="Create New NPC for Secret Identity",
            command=create_new_identity,
        ).pack(anchor="w", padx=24, pady=(0, 12))

        def save_hero():
            name = name_entry.get().strip()
            if not name:
                messagebox.showerror("Missing Hero Name", "Enter a hero name.", parent=win)
                return

            if any(r.get("name", "").lower() == name.lower() for r in self.data["heroes"]):
                messagebox.showerror(
                    "Duplicate Hero",
                    f"{name} already exists.",
                    parent=win,
                )
                return

            selected_npc = npc_var.get().strip()

            if not selected_npc:
                create_npc = messagebox.askyesno(
                    "Secret Identity NPC",
                    "No NPC was selected for this hero's secret identity.\\n\\n"
                    "Would you like to create a new NPC and link it to this hero?",
                    parent=win,
                )

                if create_npc:
                    suggested = simpledialog.askstring(
                        "New Secret Identity NPC",
                        "NPC name / secret identity:",
                        parent=win,
                    )

                    if suggested and suggested.strip():
                        self.create_npc_for_secret_identity(
                            suggested_name=suggested.strip(),
                            parent=win,
                        )
                        npc_records[:] = self.data.setdefault("npcs", [])
                        npc_names[:] = [
                            str(n.get("name", "")).strip()
                            for n in npc_records
                            if str(n.get("name", "")).strip()
                        ]
                        npc_combo["values"] = npc_names
                        if suggested.strip() in npc_names:
                            npc_var.set(suggested.strip())
                            selected_npc = suggested.strip()

                if not selected_npc:
                    messagebox.showwarning(
                        "Secret Identity Required",
                        "A hero cannot be created without an NPC representing their secret identity.",
                        parent=win,
                    )
                    return

            record = {
                "name": name,
                "aliases": [selected_npc],
                "powers": [
                    x.strip()
                    for x in powers_entry.get().split(",")
                    if x.strip()
                ],
                "feats": [],
                "teams": ["Unknown"],
                "weaknesses": [],
                "civilian_identity": selected_npc,
                "reputation": "Unknown",
                "sightings": [],
            }

            self.data["heroes"].append(record)

            try:
                save_data(self.data)
            except Exception as exc:
                self.data["heroes"].remove(record)
                messagebox.showerror(
                    "Save Error",
                    f"The hero could not be saved.\\n\\nError: {exc}",
                    parent=win,
                )
                return

            win.destroy()
            self.show_page("Heroes")
            self.status.config(text=f"Created hero {name} linked to NPC {selected_npc}")

        button_bar = tk.Frame(win, bg=self.BG)
        button_bar.pack(fill="x", padx=24, pady=12)

        ttk.Button(
            button_bar,
            text="Create Hero",
            command=save_hero,
        ).pack(side="right", padx=4)

        ttk.Button(
            button_bar,
            text="Cancel",
            command=win.destroy,
        ).pack(side="right", padx=4)

    def create_npc_for_secret_identity(self, suggested_name="", parent=None):
        """Create and save an NPC specifically for use as a secret identity."""
        name = suggested_name.strip()

        if not name:
            name = simpledialog.askstring(
                "New Secret Identity NPC",
                "NPC name / secret identity:",
                parent=parent or self.root,
            )
            if not name:
                return None
            name = name.strip()

        if not name:
            return None

        if any(
            str(n.get("name", "")).strip().lower() == name.lower()
            for n in self.data.setdefault("npcs", [])
        ):
            messagebox.showerror(
                "Duplicate NPC",
                f"An NPC named {name} already exists.",
                parent=parent or self.root,
            )
            return None

        record = {
            "name": name,
            "alias": "",
            "role": "",
            "description": "",
            "relationships": [],
            "notes": "Created as a secret identity for a hero.",
        }

        self.data["npcs"].append(record)

        try:
            save_data(self.data)
        except Exception as exc:
            self.data["npcs"].remove(record)
            messagebox.showerror(
                "NPC Save Error",
                f"The NPC could not be saved.\\n\\nError: {exc}",
                parent=parent or self.root,
            )
            return None

        return record


    def add_hero(self):
        hero = introduce_hero(self.data)
        if hero:
            save_data(self.data)
            messagebox.showinfo(
                "New Hero",
                f"{hero['name']} has been added to the Hero Lexicon."
            )
            self.show_page("Heroes")
        else:
            messagebox.showinfo(
                "No New Hero",
                "The random hero template pool has been exhausted."
            )

    def add_villain(self):
        villain = introduce_villain(self.data)
        if villain:
            save_data(self.data)
            messagebox.showinfo(
                "New Villain",
                f"{villain['name']} has been added to the Villain Database."
            )
            self.show_page("Villains")
        else:
            messagebox.showinfo(
                "No New Villain",
                "The random villain template pool has been exhausted."
            )

    # ========================================================
    # PLACES
    # ========================================================

    def build_places_page(self):
        container = tk.Frame(self.content, bg=self.BG)
        container.pack(fill="both", expand=True, padx=18, pady=18)

        top = tk.Frame(container, bg=self.BG)
        top.pack(fill="x", pady=(0, 10))

        tk.Label(
            top,
            text="HERO CITY PLACES",
            bg=self.BG,
            fg=self.TEXT,
            font=("Segoe UI", 16, "bold"),
        ).pack(side="left")

        ttk.Button(
            top,
            text="Discover Place",
            command=self.add_place,
        ).pack(side="right")

        tree_frame = tk.Frame(container, bg=self.PANEL)
        tree_frame.pack(fill="both", expand=True)

        tree = ttk.Treeview(
            tree_frame,
            columns=("name", "type", "description", "tags", "incidents"),
            show="headings",
        )

        headings = {
            "name": "Place",
            "type": "Type",
            "description": "Description",
            "tags": "Tags",
            "incidents": "Incidents",
        }

        widths = {
            "name": 190,
            "type": 120,
            "description": 420,
            "tags": 230,
            "incidents": 100,
        }

        for col in headings:
            tree.heading(col, text=headings[col])
            tree.column(col, width=widths[col], anchor="w")

        tree.pack(side="left", fill="both", expand=True)

        scrollbar = ttk.Scrollbar(
            tree_frame,
            orient="vertical",
            command=tree.yview,
        )
        scrollbar.pack(side="right", fill="y")
        tree.configure(yscrollcommand=scrollbar.set)

        for place in self.data["places"]:
            tree.insert(
                "",
                "end",
                values=(
                    place["name"],
                    place["type"],
                    place["description"],
                    ", ".join(place.get("tags", [])),
                    len(place.get("incidents", [])),
                ),
            )

        tree.bind(
            "<Double-1>",
            lambda event: self.open_place_record(tree),
        )

        tk.Label(
            container,
            text="Double-click a location to view its incident history.",
            bg=self.BG,
            fg=self.MUTED,
        ).pack(anchor="w", pady=(8, 0))

    def open_place_record(self, tree):
        """Open a scrollable location dossier with a clearly visible Save button."""
        selected = tree.selection()
        if not selected:
            return

        values = tree.item(selected[0], "values")
        if not values:
            return

        place = find_record(self.data["places"], values[0])
        if not place:
            return

        win = tk.Toplevel(self.root)
        win.title(f"{place['name']} — Location Dossier")
        win.geometry("760x700")
        win.minsize(650, 500)
        win.configure(bg=self.BG)
        win.transient(self.root)
        win.grab_set()

        canvas = tk.Canvas(win, bg=self.BG, highlightthickness=0)
        scrollbar = ttk.Scrollbar(win, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        form = tk.Frame(canvas, bg=self.BG)
        window_id = canvas.create_window((0, 0), window=form, anchor="nw")

        def update_scroll_region(event=None):
            canvas.configure(scrollregion=canvas.bbox("all"))
            canvas.itemconfigure(window_id, width=canvas.winfo_width())

        form.bind("<Configure>", update_scroll_region)
        canvas.bind("<Configure>", update_scroll_region)

        def wheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

        canvas.bind_all("<MouseWheel>", wheel)

        def close_window():
            canvas.unbind_all("<MouseWheel>")
            win.destroy()

        win.protocol("WM_DELETE_WINDOW", close_window)

        tk.Label(
            form, text=place["name"], bg=self.BG, fg=self.TEXT,
            font=("Segoe UI", 18, "bold")
        ).pack(anchor="w", padx=20, pady=(20, 2))

        tk.Label(
            form,
            text=f"{place['type']}  •  {', '.join(place.get('tags', []))}",
            bg=self.BG, fg=self.MUTED,
        ).pack(anchor="w", padx=20)

        tk.Label(
            form, text="DESCRIPTION", bg=self.BG, fg=self.MUTED,
            font=("Segoe UI", 9, "bold")
        ).pack(anchor="w", padx=20, pady=(15, 3))

        desc = tk.Text(
            form, height=8, bg=self.PANEL, fg=self.TEXT,
            insertbackground="#ffffff", relief="flat", wrap="word"
        )
        desc.insert("1.0", place.get("description", ""))
        desc.pack(fill="x", padx=20)

        tk.Label(
            form, text="INCIDENT HISTORY", bg=self.BG, fg=self.TEXT,
            font=("Segoe UI", 11, "bold")
        ).pack(anchor="w", padx=20, pady=(15, 3))

        incidents = tk.Text(
            form, height=14, bg=self.PANEL, fg=self.TEXT,
            relief="flat", wrap="word"
        )
        incidents.pack(fill="x", padx=20)

        for incident in place.get("incidents", []):
            if incident.get("title"):
                incidents.insert(
                    "end",
                    f"{incident.get('timestamp', incident.get('date', ''))}\n"
                    f"{incident.get('title', '')}\n"
                    f"Heroes: {', '.join(incident.get('heroes', [])) or 'None'}\n"
                    f"Villains: {', '.join(incident.get('villains', [])) or 'None'}\n\n"
                    f"Scenario: {incident.get('scenario', '')}\n\n"
                    f"Outcome: {incident.get('outcome', '')}\n"
                    + "-" * 60 + "\n\n"
                )
            else:
                incidents.insert(
                    "end",
                    f"{incident.get('timestamp', '')}\n"
                    f"{incident.get('description', '')}\n"
                    f"Source: {incident.get('source', '')}\n\n"
                )

        # Keep incident history read-only: it is generated by the incident
        # builder. The location description itself remains editable.
        incidents.configure(state="disabled")

        button_bar = tk.Frame(form, bg=self.BG)
        button_bar.pack(fill="x", padx=20, pady=15)

        def save():
            try:
                place["description"] = desc.get("1.0", "end-1c").strip()
                save_data(self.data)
            except Exception as exc:
                messagebox.showerror(
                    "Could Not Save Location",
                    "The location could not be saved.\n\n"
                    f"Error: {exc}\n\n"
                    "Your changes are still open.",
                    parent=win,
                )
                return

            messagebox.showinfo(
                "Location Saved",
                f"{place['name']} has been saved.",
                parent=win
            )
            close_window()
            self.show_page("Places")
            self.status.config(text=f"Saved location: {place['name']}")

        ttk.Button(
            button_bar, text="Save Location", command=save
        ).pack(side="right", padx=4)

        ttk.Button(
            button_bar, text="Cancel", command=close_window
        ).pack(side="right", padx=4)

        canvas.yview_moveto(0)


    def add_place(self):
        place = discover_place(self.data)
        if place:
            save_data(self.data)
            messagebox.showinfo(
                "New Place",
                f"{place['name']} has been added to Hero City."
            )
            self.show_page("Places")
        else:
            messagebox.showinfo(
                "No New Place",
                "The random location template pool has been exhausted."
            )

    # ========================================================
    # NPCS / ORGANIZATIONS
    # ========================================================

    def build_reference_page(self, key, title, singular):
        """Build an editable database page for NPCs or organizations."""
        container = tk.Frame(self.content, bg=self.BG)
        container.pack(fill="both", expand=True, padx=18, pady=18)

        top = tk.Frame(container, bg=self.BG)
        top.pack(fill="x", pady=(0, 10))

        tk.Label(
            top, text=title, bg=self.BG, fg=self.TEXT,
            font=("Segoe UI", 16, "bold")
        ).pack(side="left")

        ttk.Button(
            top, text="Delete Selected",
            command=lambda: self.delete_reference(key, tree, singular)
        ).pack(side="right", padx=4)

        ttk.Button(
            top, text=f"Add {singular}",
            command=lambda: self.add_reference(key, singular)
        ).pack(side="right", padx=4)

        search_var = tk.StringVar()
        tk.Entry(
            top, textvariable=search_var, bg=self.PANEL, fg=self.TEXT,
            insertbackground="#ffffff", relief="flat", font=("Segoe UI", 10)
        ).pack(side="right", padx=8, ipadx=10, ipady=7)
        tk.Label(top, text="Search:", bg=self.BG, fg=self.MUTED).pack(side="right")

        tree_frame = tk.Frame(container, bg=self.PANEL)
        tree_frame.pack(fill="both", expand=True)

        if key == "npcs":
            columns = ("name", "alias", "role", "description")
            headings = {"name": "NPC / Secret Identity", "alias": "Public Alias", "role": "Role", "description": "Description"}
            widths = {"name": 190, "alias": 150, "role": 220, "description": 500}
        else:
            columns = ("name", "type", "description", "members")
            headings = {"name": "Organization", "type": "Type", "description": "Description", "members": "Members"}
            widths = {"name": 240, "type": 180, "description": 480, "members": 260}

        tree = ttk.Treeview(tree_frame, columns=columns, show="headings", selectmode="browse")
        for col in columns:
            tree.heading(col, text=headings[col])
            tree.column(col, width=widths[col], anchor="w")
        tree.pack(side="left", fill="both", expand=True)

        scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
        scrollbar.pack(side="right", fill="y")
        tree.configure(yscrollcommand=scrollbar.set)

        def populate(*_):
            tree.delete(*tree.get_children())
            query = search_var.get().lower().strip()
            for record in self.data.get(key, []):
                if query and query not in json.dumps(record).lower():
                    continue
                if key == "npcs":
                    values = (
                        record.get("name", ""),
                        record.get("alias", ""),
                        record.get("role", ""),
                        record.get("description", ""),
                    )
                else:
                    values = (
                        record.get("name", ""),
                        record.get("type", ""),
                        record.get("description", ""),
                        ", ".join(record.get("members", [])),
                    )
                tree.insert("", "end", iid=record.get("name", ""), values=values)

        search_var.trace_add("write", populate)
        populate()
        tree.bind("<Double-1>", lambda event: self.open_reference_record(key, tree, singular))

        tk.Label(
            container,
            text=f"Double-click a {singular.lower()} to edit its dossier. Changes are saved with Save {singular}.",
            bg=self.BG, fg=self.MUTED
        ).pack(anchor="w", pady=(8, 0))

    def open_reference_record(self, key, tree, singular):
        selected = tree.selection()
        if not selected:
            return
        values = tree.item(selected[0], "values")
        if not values:
            return
        record = find_record(self.data.get(key, []), values[0])
        if record:
            self.reference_editor(key, record, singular)

    def reference_editor(self, key, record, singular):
        """Open a scrollable editor for an NPC or organization."""
        win = tk.Toplevel(self.root)
        win.title(f"{record.get('name', singular)} — {singular} Dossier")
        win.geometry("760x700")
        win.minsize(650, 500)
        win.configure(bg=self.BG)
        win.transient(self.root)
        win.grab_set()

        canvas = tk.Canvas(win, bg=self.BG, highlightthickness=0)
        scrollbar = ttk.Scrollbar(win, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        form = tk.Frame(canvas, bg=self.BG)
        window_id = canvas.create_window((0, 0), window=form, anchor="nw")

        def update_scroll_region(event=None):
            canvas.configure(scrollregion=canvas.bbox("all"))
            canvas.itemconfigure(window_id, width=canvas.winfo_width())

        form.bind("<Configure>", update_scroll_region)
        canvas.bind("<Configure>", update_scroll_region)

        def wheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

        canvas.bind_all("<MouseWheel>", wheel)

        def close_window():
            canvas.unbind_all("<MouseWheel>")
            win.destroy()

        win.protocol("WM_DELETE_WINDOW", close_window)

        tk.Label(
            form, text=f"{singular.upper()} DOSSIER", bg=self.BG, fg=self.TEXT,
            font=("Segoe UI", 18, "bold")
        ).pack(anchor="w", padx=20, pady=(20, 8))

        fields = {}

        def add_entry(label, field_name):
            tk.Label(form, text=label, bg=self.BG, fg=self.MUTED, anchor="w").pack(
                fill="x", padx=20, pady=(7, 2)
            )
            entry = tk.Entry(
                form, bg=self.PANEL, fg=self.TEXT,
                insertbackground="#ffffff", relief="flat"
            )
            value = record.get(field_name, "")
            if isinstance(value, list):
                value = ", ".join(value)
            entry.insert(0, value)
            entry.pack(fill="x", padx=20, ipady=7)
            fields[field_name] = entry

        def add_text(label, field_name, height=7):
            tk.Label(form, text=label, bg=self.BG, fg=self.MUTED, anchor="w").pack(
                fill="x", padx=20, pady=(10, 2)
            )
            text = tk.Text(
                form, height=height, bg=self.PANEL, fg=self.TEXT,
                insertbackground="#ffffff", relief="flat", wrap="word"
            )
            value = record.get(field_name, "")
            if isinstance(value, list):
                value = "\n".join(str(x) for x in value)
            text.insert("1.0", value)
            text.pack(fill="x", padx=20)
            fields[field_name] = text

        if key == "npcs":
            add_entry("Name", "name")
            add_entry("Alias / Public Name", "alias")
            add_entry("Role / Occupation", "role")
            add_text("Description", "description", 7)
            add_text("Relationships (one per line)", "relationships", 6)
            add_text("Notes (one per line)", "notes", 8)
        else:
            add_entry("Name", "name")
            add_entry("Type / Category", "type")
            add_text("Description", "description", 7)
            add_text("Members (one per line)", "members", 6)
            add_text("Notes", "notes", 8)

        button_bar = tk.Frame(form, bg=self.BG)
        button_bar.pack(fill="x", padx=20, pady=15)

        def save():
            new_name = fields["name"].get().strip()
            if not new_name:
                messagebox.showerror("Save Error", "Name cannot be blank.", parent=win)
                return

            duplicate = any(
                r is not record and r.get("name") == new_name
                for r in self.data.get(key, [])
            )
            if duplicate:
                messagebox.showerror("Save Error", f"{new_name} already exists.", parent=win)
                return

            try:
                record["name"] = new_name
                if key == "npcs":
                    record["alias"] = fields["alias"].get().strip()
                    record["role"] = fields["role"].get().strip()
                    record["description"] = fields["description"].get("1.0", "end-1c").strip()
                    record["relationships"] = [x.strip() for x in fields["relationships"].get("1.0", "end-1c").splitlines() if x.strip()]
                    record["notes"] = fields["notes"].get("1.0", "end-1c").strip()
                else:
                    record["type"] = fields["type"].get().strip()
                    record["description"] = fields["description"].get("1.0", "end-1c").strip()
                    record["members"] = [x.strip() for x in fields["members"].get("1.0", "end-1c").splitlines() if x.strip()]
                    record["notes"] = fields["notes"].get("1.0", "end-1c").strip()
                save_data(self.data)
            except Exception as exc:
                messagebox.showerror(
                    f"Could Not Save {singular}",
                    f"The {singular.lower()} could not be saved.\n\nError: {exc}\n\nYour changes are still open.",
                    parent=win,
                )
                return

            messagebox.showinfo(f"{singular} Saved", f"{record['name']} has been saved.", parent=win)
            close_window()
            self.show_page("NPCs" if key == "npcs" else "Organizations")
            self.status.config(text=f"Saved {record['name']}")

        ttk.Button(button_bar, text=f"Save {singular}", command=save).pack(side="right", padx=4)
        ttk.Button(button_bar, text="Cancel", command=close_window).pack(side="right", padx=4)
        ttk.Button(
            button_bar, text=f"Delete {singular}",
            command=lambda: self.delete_reference_from_editor(key, record, win, singular)
        ).pack(side="left")

        canvas.yview_moveto(0)

    def delete_reference_from_editor(self, key, record, editor_window, singular):
        if not messagebox.askyesno(
            "Confirm Deletion",
            f"Delete {record.get('name', 'this record')} from the {singular.lower()} database?",
            parent=editor_window,
        ):
            return
        self.data[key][:] = [r for r in self.data.get(key, []) if r is not record]
        save_data(self.data)
        editor_window.destroy()
        self.show_page("NPCs" if key == "npcs" else "Organizations")

    def delete_reference(self, key, tree, singular):
        selected = tree.selection()
        if not selected:
            messagebox.showinfo("Delete", f"Select a {singular.lower()} first.")
            return
        name = tree.item(selected[0], "values")[0]
        if not messagebox.askyesno(
            "Confirm Deletion",
            f"Delete {name} from the {singular.lower()} database?"
        ):
            return
        self.data[key][:] = [r for r in self.data.get(key, []) if r.get("name") != name]
        save_data(self.data)
        self.show_page("NPCs" if key == "npcs" else "Organizations")

    def add_reference(self, key, singular):
        record = {"name": "New " + singular}
        if key == "npcs":
            record.update({
                "alias": "", "role": "", "description": "",
                "relationships": [], "notes": "",
            })
        else:
            record.update({
                "type": "", "description": "", "members": [], "notes": "",
            })

        existing_names = {r.get("name") for r in self.data.get(key, [])}
        base = record["name"]
        counter = 2
        while record["name"] in existing_names:
            record["name"] = f"{base} {counter}"
            counter += 1

        self.data.setdefault(key, []).append(record)
        try:
            save_data(self.data)
        except Exception as exc:
            self.data[key].remove(record)
            messagebox.showerror("Save Error", str(exc))
            return

        self.reference_editor(key, record, singular)

    # ========================================================
    # SESSION NOTES
    # ========================================================

    def build_session_page(self):
        container = tk.Frame(self.content, bg=self.BG)
        container.pack(fill="both", expand=True, padx=18, pady=18)

        top = tk.Frame(container, bg=self.BG)
        top.pack(fill="x", pady=(0, 10))

        tk.Label(
            top,
            text="SESSION NOTES",
            bg=self.BG,
            fg=self.TEXT,
            font=("Segoe UI", 16, "bold"),
        ).pack(side="left")

        ttk.Button(
            top,
            text="Save Session Log",
            command=self.save_session_notes,
        ).pack(side="right", padx=4)

        ttk.Button(
            top,
            text="New Session Header",
            command=self.insert_session_header,
        ).pack(side="right", padx=4)

        ttk.Button(
            top,
            text="Open Session Log",
            command=self.load_session_notes,
        ).pack(side="right", padx=4)

        self.notes = tk.Text(
            container,
            bg=self.PANEL,
            fg=self.TEXT,
            insertbackground="#ffffff",
            selectbackground=self.ACCENT,
            relief="flat",
            wrap="word",
            undo=True,
            padx=20,
            pady=18,
            font=("Consolas", 11),
        )
        self.notes.pack(fill="both", expand=True)

        self.load_session_notes()

        tk.Label(
            container,
            text=f"Saved to: {SESSION_LOG.resolve()}",
            bg=self.BG,
            fg=self.MUTED,
        ).pack(anchor="w", pady=(8, 0))

    def load_session_notes(self):
        if SESSION_LOG.exists():
            try:
                text = SESSION_LOG.read_text(encoding="utf-8")
                self.notes.delete("1.0", "end")
                self.notes.insert("1.0", text)
                self.status.config(text=f"Loaded {SESSION_LOG.name}")
            except Exception as exc:
                messagebox.showerror(
                    "Load Error",
                    str(exc),
                )
        else:
            self.notes.delete("1.0", "end")
            self.notes.insert(
                "1.0",
                f"# HERO CITY SESSION LOG\n"
                f"# Created {datetime.now().strftime('%Y-%m-%d %H:%M')}\n\n"
            )

    def save_session_notes(self):
        try:
            text = self.notes.get("1.0", "end-1c")
            SESSION_LOG.write_text(text, encoding="utf-8")
            self.status.config(
                text=f"Saved session notes to {SESSION_LOG.name}"
            )
        except Exception as exc:
            messagebox.showerror(
                "Save Error",
                str(exc),
            )

    def insert_session_header(self):
        stamp = datetime.now().strftime("%Y-%m-%d %H:%M")
        header = (
            "\n\n"
            + "=" * 70
            + f"\nSESSION — {stamp}\n"
            + "=" * 70
            + "\n\n"
        )
        self.notes.insert("insert", header)

    # ========================================================
    # SEARCH
    # ========================================================

    def search_everything(self):
        query = simpledialog.askstring(
            "Hero City Search",
            "Search heroes, villains, places, NPCs, organizations, and posts:",
            parent=self.root,
        )

        if not query:
            return

        q = query.lower()
        results = []

        for category in ["heroes", "villains", "places", "npcs", "organizations"]:
            for record in self.data.get(category, []):
                if q in json.dumps(record).lower():
                    results.append(
                        f"[{category.upper()}] "
                        f"{record.get('name', 'Unnamed')}"
                    )

        for post in self.data["posts"]:
            if q in post.get("text", "").lower():
                results.append(
                    f"[SOCIAL] @{post['username']}: {post['text']}"
                )

        win = tk.Toplevel(self.root)
        win.title(f"Search — {query}")
        win.geometry("800x550")
        win.configure(bg=self.BG)

        text = tk.Text(
            win,
            bg=self.PANEL,
            fg=self.TEXT,
            relief="flat",
            wrap="word",
            padx=18,
            pady=18,
        )
        text.pack(fill="both", expand=True, padx=15, pady=15)

        if results:
            text.insert("1.0", "\n\n".join(results))
        else:
            text.insert("1.0", "No results found.")

    # ========================================================
    # UI HELPERS
    # ========================================================

    def make_panel_title(self, parent, title):
        tk.Label(
            parent,
            text=title,
            bg=self.PANEL,
            fg=self.MUTED,
            font=("Segoe UI", 9, "bold"),
        ).pack(anchor="w", padx=18, pady=(18, 5))

    def on_close(self):
        if self.current_page == "Session Notes":
            self.save_session_notes()
        save_data(self.data)
        self.root.destroy()


# ============================================================
# RUN
# ============================================================

if __name__ == "__main__":
    root = tk.Tk()
    app = HeroCityApp(root)
    root.mainloop()
