"""Prowlers & Paragons dice roller for the Hero City GM Dashboard."""
import random
import tkinter as tk
from tkinter import ttk


DIFFICULTIES = {
    "Easy (0)": 0,
    "Average (1)": 1,
    "Hard (2)": 2,
    "Daunting (3)": 3,
    "Brutal (4)": 4,
    "Inhuman (5)": 5,
    "Superhuman (6–8)": 6,
    "Legendary (9–11)": 9,
    "Godlike (12+)": 12,
}


class DiceRoller:
    def __init__(self, parent):
        self.parent = parent
        self.window = tk.Toplevel(parent)
        self.window.title("Prowlers & Paragons — Roll Dice")
        self.window.geometry("900x760")
        self.window.minsize(720, 600)

        self.build_ui()

    @staticmethod
    def roll_pool(dice, automatic=0, explode_sixes=False):
        dice = max(1, int(dice))
        rolls = []
        successes = int(automatic)
        pending = dice

        while pending:
            new_rolls = [random.randint(1, 6) for _ in range(pending)]
            rolls.extend(new_rolls)
            successes += sum(2 if value == 6 else 1 if value in (2, 4) else 0 for value in new_rolls)
            if explode_sixes:
                pending = sum(value == 6 for value in new_rolls)
            else:
                pending = 0

        return rolls, successes

    @staticmethod
    def format_rolls(rolls):
        return " ".join(str(x) for x in rolls) if rolls else "—"

    def build_ui(self):
        root = ttk.Frame(self.window)
        root.pack(fill="both", expand=True, padx=12, pady=12)

        title = ttk.Label(root, text="PROWLERS & PARAGONS DICE ROLLER", font=("Segoe UI", 18, "bold"))
        title.pack(anchor="w", pady=(0, 3))
        ttk.Label(
            root,
            text="2s and 4s = 1 success • 6s = 2 successes • 1 automatic success per 2 dice may be taken instead of rolling",
        ).pack(anchor="w", pady=(0, 12))

        notebook = ttk.Notebook(root)
        notebook.pack(fill="both", expand=True)

        self.challenge_tab = ttk.Frame(notebook)
        self.opposed_tab = ttk.Frame(notebook)
        self.combat_tab = ttk.Frame(notebook)
        self.tools_tab = ttk.Frame(notebook)

        notebook.add(self.challenge_tab, text="Challenge Roll")
        notebook.add(self.opposed_tab, text="Opposed Roll")
        notebook.add(self.combat_tab, text="Combat")
        notebook.add(self.tools_tab, text="Roll Tools")

        self.build_challenge_tab()
        self.build_opposed_tab()
        self.build_combat_tab()
        self.build_tools_tab()

    def dice_spin(self, parent, default=6):
        var = tk.IntVar(value=default)
        spin = ttk.Spinbox(parent, from_=0, to=100, textvariable=var, width=8)
        return var, spin

    def build_challenge_tab(self):
        frame = ttk.Frame(self.challenge_tab, padding=15)
        frame.pack(fill="both", expand=True)

        self.c_dice, c_dice = self.dice_spin(frame, 6)
        self.c_bonus, c_bonus = self.dice_spin(frame, 0)
        self.c_auto, c_auto = self.dice_spin(frame, 0)
        self.c_threshold = tk.IntVar(value=1)
        self.c_explode = tk.BooleanVar(value=False)
        self.c_resolve = tk.IntVar(value=0)

        rows = [
            ("Trait dice", c_dice),
            ("Bonus / penalty dice", c_bonus),
            ("Automatic successes", c_auto),
        ]
        for i, (label, widget) in enumerate(rows):
            ttk.Label(frame, text=label).grid(row=i, column=0, sticky="w", pady=6)
            widget.grid(row=i, column=1, sticky="w", padx=10)

        ttk.Label(frame, text="Difficulty / threshold").grid(row=3, column=0, sticky="w", pady=6)
        combo = ttk.Combobox(frame, values=list(DIFFICULTIES.keys()), state="readonly", width=22)
        combo.current(1)
        combo.grid(row=3, column=1, sticky="w", padx=10)
        combo.bind("<<ComboboxSelected>>", lambda e: self.c_threshold.set(DIFFICULTIES[combo.get()]))

        ttk.Label(frame, text="Extra Resolve dice").grid(row=4, column=0, sticky="w", pady=6)
        ttk.Spinbox(frame, from_=0, to=30, textvariable=self.c_resolve, width=8).grid(row=4, column=1, sticky="w", padx=10)

        ttk.Checkbutton(frame, text="Explode 6s (optional rule/spend)", variable=self.c_explode).grid(row=5, column=0, columnspan=2, sticky="w", pady=8)
        ttk.Button(frame, text="ROLL CHALLENGE", command=self.roll_challenge).grid(row=6, column=0, columnspan=2, sticky="w", pady=12)

        self.c_result = self.result_box(frame, 7)

    def roll_challenge(self):
        dice = max(1, self.c_dice.get() + self.c_bonus.get() + self.c_resolve.get())
        rolls, successes = self.roll_pool(dice, self.c_auto.get(), self.c_explode.get())
        threshold = self.c_threshold.get()
        net = successes - threshold
        control = "Actor" if net >= 3 else "Actor with Embellishment" if net >= 1 else "Opponent with Embellishment" if net >= -1 else "Opponent"
        self.c_result.set(f"Dice: {self.format_rolls(rolls)}\nSuccesses: {successes}\nThreshold: {threshold}\nNet successes: {net}\nNarrative control: {control}")

    def build_opposed_tab(self):
        frame = ttk.Frame(self.opposed_tab, padding=15)
        frame.pack(fill="both", expand=True)
        self.a_dice, a = self.dice_spin(frame, 6)
        self.d_dice, d = self.dice_spin(frame, 6)
        self.a_mod, am = self.dice_spin(frame, 0)
        self.d_mod, dm = self.dice_spin(frame, 0)
        for row, label, widget in [(0, "Actor dice", a), (1, "Opponent dice", d), (2, "Actor modifier", am), (3, "Opponent modifier", dm)]:
            ttk.Label(frame, text=label).grid(row=row, column=0, sticky="w", pady=6)
            widget.grid(row=row, column=1, sticky="w", padx=10)
        ttk.Button(frame, text="ROLL BOTH", command=self.roll_opposed).grid(row=4, column=0, columnspan=2, sticky="w", pady=12)
        self.o_result = self.result_box(frame, 5)

    def roll_opposed(self):
        ad, a = self.roll_pool(max(1, self.a_dice.get() + self.a_mod.get()))
        dd, d = self.roll_pool(max(1, self.d_dice.get() + self.d_mod.get()))
        net = a - d
        control = "Actor" if net >= 3 else "Actor with Embellishment" if net >= 1 else "Opponent with Embellishment" if net >= -1 else "Opponent"
        self.o_result.set(f"Actor: {self.format_rolls(ad)} → {a} successes\nOpponent: {self.format_rolls(dd)} → {d} successes\nNet successes: {net}\nNarrative control: {control}")

    def build_combat_tab(self):
        frame = ttk.Frame(self.combat_tab, padding=15)
        frame.pack(fill="both", expand=True)
        self.atk_dice, atk = self.dice_spin(frame, 6)
        self.def_dice, de = self.dice_spin(frame, 6)
        self.actions = tk.IntVar(value=1)
        self.damage_mode = tk.StringVar(value="Damage")
        for row, label, widget in [(0, "Attack dice", atk), (1, "Defense dice", de)]:
            ttk.Label(frame, text=label).grid(row=row, column=0, sticky="w", pady=6)
            widget.grid(row=row, column=1, sticky="w", padx=10)
        ttk.Label(frame, text="Actions this page").grid(row=2, column=0, sticky="w", pady=6)
        ttk.Spinbox(frame, from_=1, to=10, textvariable=self.actions, width=8).grid(row=2, column=1, sticky="w", padx=10)
        ttk.Label(frame, text="Successful attacks normally inflict 1 damage per net success.").grid(row=3, column=0, columnspan=2, sticky="w", pady=8)
        ttk.Button(frame, text="ROLL ATTACK + DEFENSE", command=self.roll_combat).grid(row=4, column=0, columnspan=2, sticky="w", pady=12)
        self.combat_result = self.result_box(frame, 5)

    def roll_combat(self):
        penalty = 2 * max(0, self.actions.get() - 1)
        ad, a = self.roll_pool(max(1, self.atk_dice.get() - penalty))
        dd, d = self.roll_pool(max(1, self.def_dice.get()))
        net = a - d
        damage = max(0, net)
        self.combat_result.set(f"Multiple-action penalty: −{penalty}d\nAttack: {self.format_rolls(ad)} → {a}\nDefense: {self.format_rolls(dd)} → {d}\nNet successes: {net}\nDamage: {damage}\nSpecial-effect duration, when applicable: 1 page per 2 net successes, rounded up.")

    def build_tools_tab(self):
        frame = ttk.Frame(self.tools_tab, padding=15)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="Useful GM reminders", font=("Segoe UI", 12, "bold")).pack(anchor="w")
        reminders = (
            "• If penalties reduce a pool below 1d, roll 1d; only a 6 earns 1 success.\n"
            "• You may take 1 automatic success for every 2 dice you choose not to roll.\n"
            "• Resolve can add dice to a challenge roll or reroll a challenge roll.\n"
            "• Multiple actions: −2d to each challenge roll for every extra action.\n"
            "• Attacks are opposed by the target's defense roll; net successes determine damage/effects.\n"
            "• Static thresholds: Easy 0, Average 1, Hard 2, Daunting 3, Brutal 4, Inhuman 5,\n"
            "  Superhuman 6–8, Legendary 9–11, Godlike 12+."
        )
        ttk.Label(frame, text=reminders, justify="left").pack(anchor="w", pady=10)

    def result_box(self, parent, row):
        var = tk.StringVar(value="Ready to roll.")
        label = ttk.Label(parent, textvariable=var, justify="left", wraplength=760)
        label.grid(row=row, column=0, columnspan=3, sticky="nw", pady=15)
        return var
