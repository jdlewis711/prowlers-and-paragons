"""Prowlers & Paragons rules viewer for the Hero City GM Dashboard."""
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox

try:
    import fitz  # PyMuPDF
except ImportError:
    fitz = None


class RulesWindow:
    def __init__(self, parent, pdf_path):
        self.parent = parent
        self.pdf_path = Path(pdf_path)
        self.window = tk.Toplevel(parent)
        self.window.title("Prowlers & Paragons — Rules")
        self.window.geometry("1050x800")
        self.window.minsize(700, 500)

        self.doc = None
        self.page_number = 0
        self.photo = None
        self.zoom = 1.25

        self.build_ui()

        if fitz is None:
            self.show_error(
                "PyMuPDF is required to display the PDF inside the application.\n\n"
                "Install it with:\n\npip install pymupdf"
            )
            return

        if not self.pdf_path.exists():
            self.show_error(
                f"The rules PDF could not be found:\n\n{self.pdf_path}\n\n"
                "Place the Prowlers & Paragons PDF beside the dashboard or update its path."
            )
            return

        try:
            self.doc = fitz.open(str(self.pdf_path))
            self.render_page()
        except Exception as exc:
            self.show_error(f"Could not open the rules PDF.\n\n{exc}")

    def build_ui(self):
        toolbar = ttk.Frame(self.window)
        toolbar.pack(fill="x", padx=8, pady=8)

        ttk.Button(toolbar, text="◀ Previous", command=self.previous_page).pack(side="left")
        ttk.Button(toolbar, text="Next ▶", command=self.next_page).pack(side="left", padx=5)
        ttk.Button(toolbar, text="Zoom −", command=lambda: self.change_zoom(-0.15)).pack(side="left", padx=(18, 3))
        ttk.Button(toolbar, text="Zoom +", command=lambda: self.change_zoom(0.15)).pack(side="left")

        self.page_label = ttk.Label(toolbar, text="No PDF loaded")
        self.page_label.pack(side="left", padx=20)

        self.canvas = tk.Canvas(self.window, background="#333333", highlightthickness=0)
        ybar = ttk.Scrollbar(self.window, orient="vertical", command=self.canvas.yview)
        xbar = ttk.Scrollbar(self.window, orient="horizontal", command=self.canvas.xview)
        self.canvas.configure(yscrollcommand=ybar.set, xscrollcommand=xbar.set)

        self.canvas.pack(side="left", fill="both", expand=True)
        ybar.pack(side="right", fill="y")
        xbar.pack(side="bottom", fill="x")

        self.window.bind("<Prior>", lambda e: self.previous_page())
        self.window.bind("<Next>", lambda e: self.next_page())
        self.window.bind("<Control-minus>", lambda e: self.change_zoom(-0.15))
        self.window.bind("<Control-plus>", lambda e: self.change_zoom(0.15))

    def show_error(self, message):
        self.page_label.config(text="Rules unavailable")
        messagebox.showerror("Rules Viewer", message, parent=self.window)

    def render_page(self):
        if not self.doc:
            return
        page = self.doc.load_page(self.page_number)
        matrix = fitz.Matrix(self.zoom, self.zoom)
        pix = page.get_pixmap(matrix=matrix, alpha=False)
        image = tk.PhotoImage(data=pix.tobytes("ppm"))
        self.photo = image
        self.canvas.delete("all")
        self.canvas.create_image(10, 10, anchor="nw", image=image)
        self.canvas.configure(scrollregion=(0, 0, pix.width + 20, pix.height + 20))
        self.page_label.config(text=f"Page {self.page_number + 1} of {len(self.doc)}")
        self.canvas.xview_moveto(0)
        self.canvas.yview_moveto(0)

    def previous_page(self):
        if self.doc and self.page_number > 0:
            self.page_number -= 1
            self.render_page()

    def next_page(self):
        if self.doc and self.page_number < len(self.doc) - 1:
            self.page_number += 1
            self.render_page()

    def change_zoom(self, amount):
        self.zoom = max(0.5, min(3.0, self.zoom + amount))
        self.render_page()
