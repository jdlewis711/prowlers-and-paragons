"""Procedural content generators for the Hero City GM dashboard.

This module contains the reusable random-content engine: templates,
selection helpers, social-feed generation, and random hero/villain/location
introduction. It mutates the campaign data structure supplied by the caller.
"""

import random
from datetime import datetime


LOCATION_TEMPLATES = [
    ("The Glass District", "District", "A wealthy neighborhood dominated by modern architecture.", ["wealth", "corporate", "nightlife"]),
    ("Blackstone Station", "Transit", "A major subway and commuter rail station.", ["transit", "crowds", "crime"]),
    ("Rook Street", "Street", "A narrow street known for pawn shops, bars, and unusual nightlife.", ["nightlife", "crime", "underground"]),
    ("Starlight Plaza", "Plaza", "A popular downtown gathering place surrounded by restaurants and shops.", ["tourism", "shopping", "events"]),
    ("Westbridge", "Neighborhood", "A dense residential neighborhood west of downtown.", ["residential", "families", "working-class"]),
    ("The Narrows", "Neighborhood", "A crowded waterfront district with a reputation for organized crime.", ["crime", "waterfront", "poverty"]),
    ("Mercy General Hospital", "Hospital", "One of Hero City's largest hospitals.", ["medical", "emergency", "heroes"]),
    ("Atlas Tower", "Building", "A 70-story corporate tower overlooking downtown.", ["corporate", "wealth", "technology"]),
    ("Hawthorne Bridge", "Bridge", "A major bridge connecting downtown with Westbridge.", ["traffic", "river", "infrastructure"]),
    ("Redline Subway", "Transit", "The city's oldest subway line.", ["transit", "underground", "crime"]),
]

HERO_TEMPLATES = [
    ("The Warden", ["Warden"], ["energy barriers", "enhanced strength"]),
    ("Mirage", ["The Mirage"], ["illusion generation", "disguise"]),
    ("Comet", ["Comet"], ["flight", "super speed", "energy projection"]),
    ("Ironclad", ["Ironclad"], ["super durability", "super strength"]),
    ("Specter", ["The Specter"], ["intangibility", "invisibility"]),
]

VILLAIN_TEMPLATES = [
    ("Blackout", ["The Blackout"], ["power absorption", "electrical disruption"]),
    ("Gravitas", ["Gravitas"], ["gravity manipulation"]),
    ("The Broker", ["Broker"], ["superhuman persuasion", "information networks"]),
    ("Razorwing", ["Razorwing"], ["flight", "energy blades"]),
    ("Morrow", ["Doctor Morrow"], ["biotechnology", "mutagenic science"]),
]

FEATS = [
    "Stopped a robbery before police arrived",
    "Rescued civilians from a collapsing building",
    "Prevented a major traffic accident",
    "Fought an unidentified superhuman in public",
    "Stopped an armed gang near a residential neighborhood",
    "Evacuated civilians during a superhuman incident",
    "Prevented a train derailment",
    "Destroyed a dangerous piece of supervillain technology",
    "Helped firefighters contain a major fire",
    "Interrupted a suspected weapons deal",
    "Protected civilians during a hostage situation",
    "Was seen fighting someone on a rooftop",
]

POST_TEMPLATES = {
    "sighting": [
        "Anyone else see {hero} near {place} tonight?",
        "Just saw {hero} heading toward {place}. Something is definitely happening.",
        "Possible {hero} sighting at {place}. Can anyone confirm?",
        "Okay, pretty sure that was {hero} flying over {place}.",
    ],
    "news": [
        "BREAKING: Reports of a superhuman incident near {place}.",
        "Emergency crews responding to an incident at {place}.",
        "Multiple witnesses reporting unusual activity around {place}.",
        "Police have closed several streets around {place}.",
    ],
    "fan": [
        "{hero} continues to prove why they're one of the best heroes in Hero City.",
        "I don't care what anyone says. {hero} is AWESOME.",
        "If {hero} is actually at {place}, somebody better get video.",
        "Hero City doesn't deserve {hero}.",
    ],
    "complaint": [
        "Can someone explain why {place} is closed AGAIN?",
        "Love living in Hero City. Nothing like hearing an explosion outside your window.",
        "Apparently superhuman property damage doesn't count as a parking violation.",
        "Would really appreciate it if superheroes stopped destroying {place}. Thanks.",
    ],
    "rumor": [
        "Hearing rumors that {hero} was involved in what happened at {place}.",
        "Friend of a friend says there were TWO heroes at {place}.",
        "Apparently {hero} wasn't alone at {place}.",
        "Something weird is going on at {place}. That's all I'm saying.",
    ],
    "pulse": [
        "I've spoken with three witnesses who independently described {hero} at {place}. Still trying to confirm what happened.",
        "NEW: Multiple sources tell me {hero} was seen at {place} shortly before the incident.",
        "I'm getting reports of unusual activity at {place}. If you're nearby, send me what you're seeing.",
        "I've been tracking reports of {hero} for the last few weeks. Tonight's sighting at {place} is the clearest one yet.",
        "People are asking whether {hero} is connected to the incident at {place}. At this point, that's unconfirmed.",
    ],
    "conspiracy": [
        "Funny how {hero} always shows up right after something happens at {place}.",
        "You're telling me nobody knows who {hero} really is?",
        "Something doesn't add up about {place}.",
        "Ask yourself who benefits from what happened at {place}.",
    ],
    "local": [
        "Anyone know if the businesses around {place} are still open?",
        "Had dinner near {place} and suddenly half the street was blocked off.",
        "Hero City really needs to figure out its superhuman insurance situation.",
        "Honestly, {place} was already weird BEFORE the superheroes showed up.",
    ],
    "scanner": [
        "Scanner traffic suggests units heading toward {place}.",
        "Hearing reports of a possible powered individual at {place}.",
        "Multiple emergency units moving toward {place}.",
        "Something big happening around {place}.",
    ],
}



def weighted_user(data):
    users = data["social_users"]
    pool = []
    for user in users:
        pool.extend([user] * int(user.get("weight", 1)))
    return random.choice(pool)


def choose_person(data, include_villains=True):
    choices = []
    choices.extend([("hero", x) for x in data["heroes"]])
    if include_villains:
        choices.extend([("villain", x) for x in data["villains"]])
    return random.choice(choices) if choices else (None, None)


def choose_place(data):
    return random.choice(data["places"]) if data["places"] else None


def find_record(records, name):
    name = name.lower().strip()
    for record in records:
        if record.get("name", "").lower() == name:
            return record
    return None


# ============================================================
# SOCIAL FEED ENGINE
# ============================================================

def generate_post(data):
    user = weighted_user(data)
    _, person = choose_person(data)
    place = choose_place(data)

    if not person or not place:
        return None

    person_name = person["name"]
    place_name = place["name"]

    if user["username"] == "Pulse":
        category = "pulse"
    elif user["type"] == "fan":
        category = "fan"
    elif user["type"] == "conspiracy":
        category = "conspiracy"
    elif user["type"] == "scanner":
        category = "scanner"
    elif user["type"] == "news":
        category = "news"
    elif user["type"] == "local":
        category = random.choice(["local", "complaint"])
    else:
        category = random.choice(["sighting", "rumor", "local", "complaint"])

    text = random.choice(POST_TEMPLATES[category]).format(
        hero=person_name,
        place=place_name,
    )

    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    post = {
        "id": len(data["posts"]) + 1,
        "timestamp": now,
        "username": user["username"],
        "display_name": user["display_name"],
        "type": user["type"],
        "text": text,
        "person": person_name,
        "place": place_name,
        "category": category,
        "verified": user["username"] == "Pulse",
    }

    data["posts"].append(post)

    # Track sightings/incidents.
    if category in ("sighting", "pulse", "rumor", "scanner"):
        person.setdefault("sightings", []).append({
            "place": place_name,
            "timestamp": now,
            "source": user["username"],
            "confirmed": category == "pulse",
        })

        place.setdefault("incidents", []).append({
            "timestamp": now,
            "person": person_name,
            "source": user["username"],
            "description": text,
        })

    # Pulse occasionally turns a sighting into a recorded feat.
    if category == "pulse" and random.random() < 0.22:
        feat = random.choice(FEATS)
        if feat not in person.setdefault("feats", []):
            person["feats"].append(feat)
            post["database_update"] = feat

    return post


def introduce_hero(data):
    existing = {x["name"] for x in data["heroes"]}
    available = [x for x in HERO_TEMPLATES if x[0] not in existing]
    if not available:
        return None

    name, aliases, powers = random.choice(available)
    hero = {
        "name": name,
        "aliases": aliases,
        "powers": powers,
        "feats": [],
        "teams": ["Unknown"],
        "weaknesses": [],
        "civilian_identity": "Unknown",
        "reputation": "Unknown",
        "sightings": [],
    }
    data["heroes"].append(hero)
    return hero


def introduce_villain(data):
    existing = {x["name"] for x in data["villains"]}
    available = [x for x in VILLAIN_TEMPLATES if x[0] not in existing]
    if not available:
        return None

    name, aliases, powers = random.choice(available)
    villain = {
        "name": name,
        "aliases": aliases,
        "powers": powers,
        "feats": [],
        "teams": ["Unknown"],
        "weaknesses": [],
        "civilian_identity": "Unknown",
        "reputation": "Dangerous",
        "sightings": [],
        "crimes": [],
    }
    data["villains"].append(villain)
    return villain


def discover_place(data):
    existing = {x["name"] for x in data["places"]}
    available = [x for x in LOCATION_TEMPLATES if x[0] not in existing]
    if not available:
        return None

    name, kind, description, tags = random.choice(available)
    place = {
        "name": name,
        "type": kind,
        "description": description,
        "tags": tags,
        "associated_people": [],
        "incidents": [],
    }
    data["places"].append(place)
    return place

